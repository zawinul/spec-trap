funzionante, con 
	transpose
	2 modalità di view
	no LFO
	automove xy 
	show weights
	enhancer
	vocoder
to do:
	movimento lineare (con easing)

versione salvata prima della nuova gestione fase
