funzionante, con transpose

to do:
gestione stringhe
usabilità edit point singoli