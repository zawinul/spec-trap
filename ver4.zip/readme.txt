funzionante, con 
	transpose
	2 modalità di view
	no LFO
	automove xy 
	show weights
	enhancer

to do:
	movimento lineare (con easing)
