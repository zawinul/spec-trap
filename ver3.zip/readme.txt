funzionante, con 
	transpose
	2 modalità di view
	no LFO
	automove xy 
	show weights

to do:
	movimento lineare
